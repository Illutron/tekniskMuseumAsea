
/*
 *  Mode.cpp
 *  openframeworksQT
 *
 *  Created by Jonas Jongejan on 27/07/09.
 *  Copyright 2009 HalfdanJ. All rights reserved.
 *
 */

#include "Mode.h"

Mode::Mode(){
	widget = new QWidget();
}


