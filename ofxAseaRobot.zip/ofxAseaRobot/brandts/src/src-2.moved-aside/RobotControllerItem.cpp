/*
 *  RobotControllerItem.cpp
 *  openframeworksQT
 *
 *  Created by mads hobye on 07/07/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

#include "RobotControllerItem.h"

