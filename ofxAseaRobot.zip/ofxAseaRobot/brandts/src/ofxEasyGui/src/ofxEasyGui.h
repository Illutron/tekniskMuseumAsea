/*
 *  ofxEasyGui.h
 *  ofxEasyGui
 *
 *  Created by Pat Long on 10/02/09.
 *  Copyright 2009 Tangible Interaction. All rights reserved.
 *
 */
#ifndef _OFXEASYGUI
#define _OFXEASYGUI

#include "GuiHandler.h"

#endif
