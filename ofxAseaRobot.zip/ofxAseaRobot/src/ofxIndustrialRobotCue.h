#pragma once

class ofxIndustrialRobotCue {
public:
	float speed;
	bool isPositionCue;
	
};
