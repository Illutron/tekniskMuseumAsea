#pragma once

#define NUMBER_ZONES 30

class ofxIndustrialRobotDefines {
public:
	enum HandVariant {
		Auto = 0xf,
		Up = 0x1,
		Down = 0x2
    };
};